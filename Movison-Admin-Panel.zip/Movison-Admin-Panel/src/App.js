import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import RegistrationForm from './components/RegistrationForm';
import ForgotPassword from './components/ForgotPassword';
import Login from './components/LoginForm';
import AdvertZDashboard from './components/Advertz'; // Import the dashboard

function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Dashboard at /dashboard */}
        <Route path="/dashboard" element={<AdvertZDashboard />} />
        {/* Registration form at root path */}
        <Route path="/" element={<RegistrationForm />} />
        {/* Forgot password page at /forgot-password */}
        <Route path="/forgot-password" element={<ForgotPassword />} />
        {/* Login page at /login */}
        <Route path="/login" element={<Login />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
