// src/firebase.js
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyCCXdaIlsn7ChHpdVKHXqg4l9zV3CyCsP0",
  authDomain: "movisonapp-87387.firebaseapp.com",
  projectId: "movisonapp-87387",
  storageBucket: "movisonapp-87387.appspot.com",
  messagingSenderId: "1007217420625",
  appId: "1:1007217420625:web:d08f2b7a4d3bf0eec98b70",
  measurementId: "G-KJM8R450WT"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
console.log("Firebase initialized successfully", auth);
