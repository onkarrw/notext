import React from "react";
import Sidebar from "./Sidebar.jsx"; 

const data = [
  {
    name: "Jane Cooper",
    phone: "(225) 555-0118",
    email: "jane@microsoft.com",
    validity: "3 Months",
    remaining: "54 Days",
    revenue: "500 Rs",
    status: "Active",
  },
  {
    name: "Floyd Miles",
    phone: "(205) 555-0100",
    email: "floyd@yahoo.com",
    validity: "3 Months",
    remaining: "54 Days",
    revenue: "500 Rs",
    status: "Inactive",
  },
  {
    name: "Ronald Richards",
    phone: "(302) 555-0107",
    email: "ronald@adobe.com",
    validity: "3 Months",
    remaining: "54 Days",
    revenue: "500 Rs",
    status: "Inactive",
  },
  {
    name: "Marvin McKinney",
    phone: "(252) 555-0126",
    email: "marvin@google.com",
    validity: "3 Months",
    remaining: "54 Days",
    revenue: "500 Rs",
    status: "Active",
  },
  {
    name: "Jerome Bell",
    phone: "(629) 555-0129",
    email: "jerome@google.com",
    validity: "3 Months",
    remaining: "54 Days",
    revenue: "500 Rs",
    status: "Active",
  },
  {
    name: "Kathryn Murphy",
    phone: "(406) 555-0120",
    email: "kathryn@microsoft.com",
    validity: "3 Months",
    remaining: "54 Days",
    revenue: "500 Rs",
    status: "Active",
  },
  {
    name: "Jacob Jones",
    phone: "(208) 555-0112",
    email: "jacob@yahoo.com",
    validity: "3 Months",
    remaining: "54 Days",
    revenue: "500 Rs",
    status: "Active",
  },
  {
    name: "Kristin Watson",
    phone: "(704) 555-0127",
    email: "kristin@facebook.com",
    validity: "3 Months",
    remaining: "54 Days",
    revenue: "500 Rs",
    status: "Inactive",
  },
];

export default function AdvertZDashboard() {
  return (
    <div className="container">
      <style>{`
        body {
          font-family: 'Inter', sans-serif;
        }
        .container {
          background: #f9fbfd;
          min-height: 100vh;
          display: flex;
        }
        .sidebar {
          width: 240px;
          background: #fff;
          min-height: 100vh;
          box-shadow: 2px 0 8px #f0f1f2;
          padding: 24px 0;
        }
        .sidebar h2 {
          font-size: 22px;
          font-weight: 700;
          margin-bottom: 40px;
          color: #222;
          margin-left: 28px;
        }
        .sidebar ul {
          list-style: none;
          padding: 0;
        }
        .sidebar li {
          padding: 14px 28px;
          color: #222;
          font-weight: 500;
          cursor: pointer;
          border-left: 4px solid transparent;
          transition: background 0.2s;
        }
        .sidebar li.active, .sidebar li:hover {
          background: #f0f6ff;
          color: #2e5bff;
          border-left: 4px solid #2e5bff;
        }
        .main-content {
          flex: 1;
          padding: 32px 48px;
        }
        .topbar {
          display: flex;
          justify-content: flex-end;
          align-items: center;
          margin-bottom: 18px;
        }
        .topbar .avatar {
          width: 40px;
          height: 40px;
          border-radius: 50%;
          margin-left: 18px;
          border: 2px solid #e0e6ed;
        }
        .topbar .admin-info {
          font-weight: 600;
          margin-left: 10px;
        }
        .stats-row {
          display: flex;
          gap: 30px;
          margin-bottom: 34px;
        }
        .stat-card {
          background: #fff;
          border-radius: 12px;
          padding: 20px 32px;
          box-shadow: 0 2px 8px #f0f1f2;
          flex: 1;
          display: flex;
          flex-direction: column;
          align-items: flex-start;
        }
        .stat-title {
          font-size: 15px;
          color: #8a94a6;
          font-weight: 500;
        }
        .stat-value {
          font-size: 28px;
          font-weight: 700;
          color: #222;
          margin: 12px 0 6px 0;
        }
        .stat-trend.up {
          color: #23b26d;
          font-size: 13px;
        }
        .stat-trend.down {
          color: #e14d4d;
          font-size: 13px;
        }
        .stat-trend.neutral {
          color: #2e5bff;
          font-size: 13px;
        }
        .advertz-header {
          font-size: 21px;
          font-weight: 700;
          color: #222;
          margin-bottom: 4px;
        }
        .active-adds-link {
          color: #2e5bff;
          font-size: 15px;
          margin-bottom: 12px;
          display: inline-block;
          text-decoration: underline;
          cursor: pointer;
        }
        .add-btn {
          background: #2e5bff;
          color: #fff;
          border: none;
          border-radius: 6px;
          padding: 10px 22px;
          font-weight: 600;
          font-size: 15px;
          float: right;
          margin-bottom: 14px;
          cursor: pointer;
        }
        .search-box {
          float: right;
          margin-left: 18px;
          padding: 8px 14px;
          border: 1px solid #e0e6ed;
          border-radius: 6px;
          font-size: 15px;
        }
        .advertz-table {
          width: 100%;
          border-collapse: collapse;
          background: #fff;
          border-radius: 12px;
          overflow: hidden;
          box-shadow: 0 2px 8px #f0f1f2;
        }
        .advertz-table th, .advertz-table td {
          padding: 13px 14px;
          text-align: left;
          border-bottom: 1px solid #f0f1f2;
          font-size: 15px;
        }
        .advertz-table th {
          background: #f9fbfd;
          color: #8a94a6;
          font-weight: 600;
        }
        .status-btn {
          border: none;
          border-radius: 6px;
          padding: 6px 18px;
          font-weight: 600;
          font-size: 14px;
          cursor: pointer;
        }
        .status-btn.active {
          background: #e6f4ff;
          color: #2e5bff;
        }
        .status-btn.inactive {
          background: #ffeaea;
          color: #e14d4d;
        }
        .edit-btn {
          border: 1px solid #2e5bff;
          background: #fff;
          color: #2e5bff;
          border-radius: 6px;
          padding: 6px 18px;
          font-weight: 600;
          font-size: 14px;
          cursor: pointer;
          margin-left: 8px;
        }
        .pagination {
          margin: 18px 0 0 0;
          display: flex;
          gap: 8px;
        }
        .pagination-btn {
          border: none;
          background: #f0f1f2;
          color: #2e5bff;
          border-radius: 4px;
          padding: 6px 12px;
          font-weight: 600;
          cursor: pointer;
        }
        .pagination-btn.active {
          background: #2e5bff;
          color: #fff;
        }
      `}</style>
      <Sidebar />
      <div className="main-content">
        <div className="topbar">
          <span style={{ fontSize: "16px", fontWeight: 600, marginRight: 6 }}>EN</span>
          <img
            className="avatar"
            src="https://randomuser.me/api/portraits/men/32.jpg"
            alt="Vishal"
          />
          <span className="admin-info">
            Vishal<br />
            <span style={{ fontWeight: 400, fontSize: "13px", color: "#8a94a6" }}>Admin</span>
          </span>
        </div>
        <div className="stats-row">
          <div className="stat-card">
            <div className="stat-title">Total Adds</div>
            <div className="stat-value">40,689</div>
            <div className="stat-trend up">▲ 8.5% Up from yesterday</div>
          </div>
          <div className="stat-card">
            <div className="stat-title">Total Active Adds</div>
            <div className="stat-value">10,293</div>
            <div className="stat-trend neutral">▲ 1.3% Up from past week</div>
          </div>
          <div className="stat-card">
            <div className="stat-title">Total add Revenue</div>
            <div className="stat-value">$89,000</div>
            <div className="stat-trend down">▼ 4.3% Down from yesterday</div>
          </div>
          <div className="stat-card">
            <div className="stat-title">Total Pending Payments</div>
            <div className="stat-value">2040</div>
            <div className="stat-trend up">▲ 1.8% Up from yesterday</div>
          </div>
        </div>
        <div style={{ marginBottom: 12, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div>
            <div className="advertz-header">ADVERTZ</div>
            <div className="active-adds-link">Active Adds</div>
          </div>
          <div>
            <input className="search-box" placeholder="Search" />
            <button className="add-btn">Add NewAdvertise</button>
          </div>
        </div>
        <table className="advertz-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Phone Number</th>
              <th>Email</th>
              <th>Validity</th>
              <th>Remaining Time</th>
              <th>Revenue</th>
              <th>Status</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {data.map((row, idx) => (
              <tr key={idx}>
                <td>{row.name}</td>
                <td>{row.phone}</td>
                <td>{row.email}</td>
                <td>{row.validity}</td>
                <td>{row.remaining}</td>
                <td>{row.revenue}</td>
                <td>
                  <button
                    className={`status-btn ${row.status.toLowerCase()}`}
                  >
                    {row.status}
                  </button>
                </td>
                <td>
                  <button className="edit-btn">Edit</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <div style={{ color: "#8a94a6", fontSize: 14, marginTop: 8 }}>
          Showing data 1 to 8 of 256K entries
        </div>
        <div className="pagination">
          <button className="pagination-btn active">1</button>
          <button className="pagination-btn">2</button>
          <button className="pagination-btn">3</button>
          <button className="pagination-btn">4</button>
          <button className="pagination-btn">...</button>
        </div>
      </div>
    </div>
  );
}
