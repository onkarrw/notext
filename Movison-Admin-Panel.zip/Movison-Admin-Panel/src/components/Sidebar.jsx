import React from 'react'

const Sidebar = () => {
  return (
    <div>
      <div className="sidebar">
        <h2>Movison</h2>
        <ul>
          <li>Dashboard</li>
          <li className="active">AdvertZ</li>
          <li>Logistics / Management</li>
          <li>New Orders</li>
          <li>Payment Overview</li>
          <li>Customer Management</li>
          <li>Employee Management</li>
          <li>Customer Support</li>
        </ul>
      </div>
    </div>
  )
}

export default Sidebar
