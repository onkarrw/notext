// src/pages/ForgotPassword.jsx

import React, { useState } from "react";
import logo from "../assets/logo.png";
import illustration from "../assets/illustration.png";

const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

const ForgotPassword = () => {
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    // Validate email with regex
    if (!emailRegex.test(email)) {
      setError("Please enter a valid email address.");
      return;
    }
    setError("");
    // Handle password reset logic here
    alert("Password reset link sent to " + email);
  };

  return (
    <div style={styles.container}>
      {/* Left Panel */}
      <div style={styles.leftPanel}>
        <div style={styles.logoRow}>
          <img src={logo} alt="MOVISON Logo" style={{ width: 40, marginRight: 14 }} />
          <span style={{ fontWeight: 700, fontSize: 28, color: "#151b2c", letterSpacing: 1 }}>
            MOVISON
          </span>
        </div>
          <img src={illustration} alt="illustration" style={styles.illustration} />
        </div>

      {/* Right Panel */}
      <div style={styles.rightPanel}>
        <form style={styles.form} onSubmit={handleSubmit} noValidate>
          <h2 style={styles.title}>Forgot you password</h2>
          <p style={styles.subtitle}>
            Enter your email below to receive a password link
          </p>
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => {
              setEmail(e.target.value);
              setError(""); // Clear error on change
            }}
            style={{
              ...styles.input,
              borderColor: error ? "#ff4d4f" : "#e0e0e0",
              background: error ? "#fff2f2" : "#f9f9fc",
            }}
            required
          />
          {error && (
            <div style={styles.error}>{error}</div>
          )}
          <button type="submit" style={styles.button}>
            Reset password
          </button>
        </form>
      </div>
    </div>
  );
};

const styles = {
  container: {
    display: "flex",
    minHeight: "100vh",
    fontFamily: "Arial, sans-serif",
    background: "#181c2f",
  },
  leftPanel: {
    flex: 1,
    background: "linear-gradient(135deg, #6a5af9 60%, #4f46e5 100%)",
    display: "flex",
    flexDirection: "column",
    alignItems: "flex-start",
    padding: "44px 0 0 44px",
    position: "relative",
    minWidth: 420,
    minHeight: "100vh",
    borderTopLeftRadius: 12,
    borderBottomLeftRadius: 12,
    overflow: "hidden",
  },
  logoRow: {
    display: "flex",
    alignItems: "center",
    marginBottom: 36,
    marginLeft: 2,
  },
  illustration: {
    width: "90%",
    maxWidth: 420,
    marginTop: 30,
    marginLeft: 10,
    borderRadius: 10,
    boxShadow: "0 6px 32px rgba(80, 80, 180, 0.10)",
  },
  rightPanel: {
    flex: 1.4,
    background: "#fff",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    position: "relative",
    borderTopRightRadius: 12,
    borderBottomRightRadius: 12,
    minHeight: "100vh",
    overflow: "hidden",
  },
  form: {
    width: 380,
    background: "#fff",
    padding: "48px 32px 36px 32px",
    borderRadius: 10,
    boxShadow: "0 8px 32px rgba(80, 80, 180, 0.10)",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    gap: 18,
  },
  title: {
    color: "#3f51f7",
    fontWeight: 700,
    fontSize: 26,
    marginBottom: 6,
    textAlign: "center",
    letterSpacing: 0.2,
  },
  subtitle: {
    color: "#b0b0b0",
    marginBottom: 28,
    fontSize: 15,
    textAlign: "center",
    fontWeight: 400,
  },
  input: {
    width: "100%",
    padding: "13px 14px",
    marginBottom: 6,
    border: "1px solid #e0e0e0",
    borderRadius: 6,
    fontSize: 16,
    background: "#f9f9fc",
    outline: "none",
    transition: "border 0.2s, background 0.2s",
  },
  error: {
    color: "#ff4d4f",
    fontSize: 14,
    marginBottom: 17,
    marginTop: -8,
    width: "100%",
    textAlign: "left",
    fontWeight: 500,
  },
  button: {
    width: "100%",
    padding: "13px 0",
    background: "#3f51f7",
    color: "#fff",
    border: "none",
    borderRadius: 6,
    fontWeight: "bold",
    fontSize: 17,
    cursor: "pointer",
    marginTop: 4,
    boxShadow: "0 2px 8px rgba(80,80,180,0.07)",
    transition: "background 0.2s",
  },
};

export default ForgotPassword;
