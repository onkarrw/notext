import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import logo from "../assets/logo.png";
import illustration from "../assets/illustration.png";

// Email regex for validation
const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

// Password strength function
function getPasswordStrength(password) {
  // Strong: min 8 chars, upper, lower, number, special
  const strong =
    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]).{8,}$/;
  // Medium: min 6 chars, at least two of (upper/lower/number)
  const medium =
    /^(?:(?=.*[a-z])(?=.*[A-Z])|(?=.*[A-Z])(?=.*\d)|(?=.*[a-z])(?=.*\d)).{6,}$/;

  if (strong.test(password)) return { label: 'Strong', color: '#22bb33' };
  if (medium.test(password)) return { label: 'Medium', color: '#e67e22' };
  if (password.length > 0) return { label: 'Weak', color: '#ff4d4f' };
  return null;
}

const RegistrationForm = () => {
  const [form, setForm] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: ''
  });
  const [emailError, setEmailError] = useState('');
  const [passwordTouched, setPasswordTouched] = useState(false);

  const navigate = useNavigate();

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    if (e.target.name === 'email') {
      setEmailError('');
    }
    if (e.target.name === 'password') {
      setPasswordTouched(true);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Email validation
    if (!emailRegex.test(form.email)) {
      setEmailError('Please enter a valid email address.');
      return;
    }
    // Password match validation
    if (form.password !== form.confirmPassword) {
      alert('Passwords do not match!');
      return;
    }
    // Password strength validation (at least medium)
    if (
      !/^(?:(?=.*[a-z])(?=.*[A-Z])|(?=.*[A-Z])(?=.*\d)|(?=.*[a-z])(?=.*\d)).{6,}$/.test(
        form.password
      )
    ) {
      alert('Password is too weak!');
      return;
    }
    alert('Registered Successfully!');
    // Optionally reset form here
  };

  const passwordStrength = getPasswordStrength(form.password);

  return (
    <div style={styles.registrationContainer}>
      <div style={styles.leftPanel}>
        <div style={styles.logoRow}>
          <img src={logo} alt="MOVISON Logo" style={styles.logo} />
          <span style={styles.companyName}>MOVISON</span>
        </div>
        <img
          src={illustration}
          alt="Illustration"
          style={styles.illustration}
        />
      </div>
      <div style={styles.rightPanel}>
        <form style={styles.registrationForm} onSubmit={handleSubmit} noValidate>
          <h2 style={styles.formTitle}>Registration</h2>
          <p style={styles.formSubtitle}>Please continue to registration</p>
          <input
            type="text"
            name="name"
            placeholder="Name"
            value={form.name}
            onChange={handleChange}
            style={styles.input}
            required
          />
          <input
            type="email"
            name="email"
            placeholder="Email"
            value={form.email}
            onChange={handleChange}
            style={{
              ...styles.input,
              borderColor: emailError ? '#ff4d4f' : '#e0e0e0',
              background: emailError ? '#fff2f2' : '#fff'
            }}
            required
          />
          {emailError && (
            <div style={styles.errorMsg}>{emailError}</div>
          )}
          <input
            type="password"
            name="password"
            placeholder="Password"
            value={form.password}
            onChange={handleChange}
            style={styles.input}
            onBlur={() => setPasswordTouched(true)}
            required
          />
          {/* Password strength indicator */}
          {passwordTouched && (
            <div
              style={{
                fontSize: 14,
                marginTop: -8,
                marginBottom: 6,
                color: passwordStrength ? passwordStrength.color : '#888'
              }}
            >
              {form.password.length === 0
                ? 'Enter a password'
                : `Password strength: ${passwordStrength.label}`}
            </div>
          )}
          <input
            type="password"
            name="confirmPassword"
            placeholder="Confirmed Password"
            value={form.confirmPassword}
            onChange={handleChange}
            style={styles.input}
            required
          />
          <button type="submit" style={styles.button}>
            Register
          </button>
          <p style={styles.loginLink}>
            Already member?{' '}
            <span
              style={styles.loginAnchor}
              onClick={() => navigate('/login')}
            >
              Login
            </span>
          </p>
        </form>
      </div>
    </div>
  );
};

const styles = {
  registrationContainer: {
    display: 'flex',
    minHeight: '100vh',
    fontFamily: 'Segoe UI, sans-serif'
  },
  leftPanel: {
    background: 'linear-gradient(135deg, #6a6ef6 60%, #a0a4ff 100%)',
    flex: 1,
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
    padding: '40px 30px',
    borderTopLeftRadius: 8,
    borderBottomLeftRadius: 8,
    position: 'relative'
  },
  logoRow: {
    display: 'flex',
    alignItems: 'center',
    marginBottom: 36,
    marginLeft: 2
  },
  logo: {
    width: 44,
    height: 44,
    marginRight: 14
  },
  companyName: {
    fontWeight: 700,
    fontSize: 28,
    color: "#151b2c",
    letterSpacing: 1
  },
  illustration: {
    width: "92%",
    maxWidth: 400,
    minWidth: 200,
    marginTop: 32,
    marginLeft: 4,
    borderRadius: 10,
    boxShadow: "0 6px 32px rgba(80, 80, 180, 0.10)",
    objectFit: "contain"
  },
  rightPanel: {
    flex: 1.2,
    background: '#fff',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    borderTopRightRadius: 8,
    borderBottomRightRadius: 8
  },
  registrationForm: {
    width: 350,
    background: '#fff',
    padding: '36px 32px',
    borderRadius: 12,
    boxShadow: '0 2px 16px rgba(80, 80, 160, 0.07)',
    display: 'flex',
    flexDirection: 'column',
    gap: 16
  },
  formTitle: {
    color: '#3b3dbb',
    marginBottom: 0
  },
  formSubtitle: {
    color: '#888',
    marginTop: 0,
    fontSize: 15
  },
  input: {
    padding: '12px 10px',
    border: '1px solid #e0e0e0',
    borderRadius: 6,
    fontSize: 15,
    outline: 'none',
    transition: 'border 0.2s',
    marginBottom: 0
  },
  button: {
    background: '#3b3dbb',
    color: '#fff',
    padding: 13,
    border: 'none',
    borderRadius: 6,
    fontSize: 16,
    marginTop: 8,
    cursor: 'pointer',
    transition: 'background 0.2s'
  },
  loginLink: {
    textAlign: 'center',
    fontSize: 14,
    marginTop: 8
  },
  loginAnchor: {
    color: '#3b3dbb',
    textDecoration: 'none',
    fontWeight: 500,
    cursor: 'pointer'
  },
  errorMsg: {
    color: '#ff4d4f',
    fontSize: 14,
    marginTop: -8,
    marginBottom: 6,
    textAlign: 'left'
  }
};

export default RegistrationForm;
