// src/pages/Login.jsx

import React, { useState } from "react";
import { useNavigate } from "react-router-dom"; // Import useNavigate
import logo from "../assets/logo.png";
import illustration from "../assets/illustration.png";
import axios from 'axios';
import { auth } from "../firebase";
import { signInWithEmailAndPassword } from "firebase/auth";


const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;


const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [remember, setRemember] = useState(false);
  const [error, setError] = useState("");
  const navigate = useNavigate(); // Initialize navigate


  const [token, setToken] = useState("");

  const handleSubmit = async (e) => { 
    e.preventDefault();
    if (!emailRegex.test(email)) {
      setError("Please enter a valid email address.");
      return;
    }
    if (!password) {
      setError("Please enter your password.");
      return;
    }
    setError("");
    alert(
      `Login Successful!\n\nEmail: ${email}\nPassword: ${password}\nRemember me: ${remember ? "Yes" : "No"}`
    );
    setError("");

    try {
      console.log("authentication", auth);
      const userCred = await signInWithEmailAndPassword(auth, email, password);
      const idToken = await userCred.user.getIdToken();
      setToken(idToken);
      console.log("Login successful, token:", idToken);
     

    } catch (err) {
      setError(err.message);
    }
  };


  return (
    <div style={styles.container}>
      {/* Left Panel */}
      <div style={styles.leftPanel}>
        <div style={styles.logo}>
          <img src={logo} alt="MOVISON Logo" style={{ width: 40, marginRight: 10 }} />
          <span style={{ fontWeight: "bold", fontSize: 28, color: "#000" }}>
            MOVISON
          </span>
        </div>
        <img
          src={illustration}
          alt="illustration"
          style={{ width: "80%", marginTop: 50, maxWidth: 400 }}
        />
      </div>

      {/* Right Panel */}
      <div style={styles.rightPanel}>
        <form style={styles.form} onSubmit={handleSubmit} noValidate>
          <h2 style={styles.title}>Welcome Back</h2>
          <p style={styles.subtitle}>
            Enter your email and password to sign in
          </p>
          <input
            type="email"
            placeholder="Your email address"
            value={email}
            onChange={(e) => {
              setEmail(e.target.value);
              setError("");
            }}
            style={{
              ...styles.input,
              borderColor: error && !emailRegex.test(email) ? "#ff4d4f" : "#dbeafe",
              background: error && !emailRegex.test(email) ? "#fff2f2" : "#f9f9fc",
            }}
            required
          />
          {error && (
            <div style={styles.error}>{error}</div>
          )}
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => {
              setPassword(e.target.value);
              setError("");
            }}
            style={styles.input}
            required
          />
          <div style={styles.optionsRow}>
            <label
              style={styles.rememberLabel}
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === " " || e.key === "Enter") setRemember((r) => !r);
              }}
            >
              <span
                style={{
                  ...styles.toggle,
                  background: remember ? "#4f46e5" : "#e4e4ef",
                }}
                onClick={() => setRemember((r) => !r)}
              >
                <span
                  style={{
                    ...styles.toggleKnob,
                    left: remember ? 16 : 2,
                  }}
                />
              </span>
              Remember me
              <input
                type="checkbox"
                checked={remember}
                onChange={() => setRemember((r) => !r)}
                style={{ display: "none" }}
              />
            </label>
            {/* Updated: clickable, purple "Forget Password" */}
            <span
              style={styles.forgotLink}
              onClick={() => navigate("/forgot-password")}
              tabIndex={0}
              onKeyDown={e => {
                if (e.key === "Enter" || e.key === " ") navigate("/forgot-password");
              }}
            >
              Forget Password
            </span>
          </div>
          <button type="submit" style={styles.button}>
            Login
          </button>
          <div style={styles.signupRow}>
            Don’t have an account?{" "}
            {/* Updated: clickable, purple "Sign up" */}
            <span
              style={styles.signupLink}
              onClick={() => navigate("/")}
              tabIndex={0}
              onKeyDown={e => {
                if (e.key === "Enter" || e.key === " ") navigate("/");
              }}
            >
              Sign up
            </span>
          </div>
        </form>
      </div>
    </div>
  );
};

const styles = {
  container: {
    display: "flex",
    minHeight: "100vh",
    fontFamily: "Arial, sans-serif",
    background: "#fff",
  },
  leftPanel: {
    flex: 1.2,
    background: "linear-gradient(135deg, #6a5af9 60%, #3f2b96 100%)",
    display: "flex",
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "flex-start",
    padding: "48px 36px 0 48px",
    position: "relative",
    overflow: "hidden",
  },
  logo: {
    display: "flex",
    alignItems: "center",
    fontSize: 28,
    fontWeight: "bold",
    marginBottom: 48,
  },
  rightPanel: {
    flex: 1,
    background: "#fff",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    position: "relative",
  },
  form: {
    width: 370,
    background: "#fff",
    padding: "40px 30px 32px 30px",
    borderRadius: 10,
    boxShadow: "0 8px 32px rgba(80, 80, 180, 0.10)",
    display: "flex",
    flexDirection: "column",
    gap: 18,
  },
  title: {
    color: "#3f51f7",
    marginBottom: 5,
    fontSize: 28,
    fontWeight: "bold",
  },
  subtitle: {
    color: "#888",
    marginBottom: 18,
    fontSize: 15,
  },
  input: {
    width: "100%",
    padding: "12px 14px",
    border: "1px solid #dbeafe",
    borderRadius: 6,
    fontSize: 16,
    marginBottom: 10,
    background: "#f9f9fc",
    outline: "none",
    transition: "border 0.2s, background 0.2s",
  },
  error: {
    color: "#ff4d4f",
    fontSize: 14,
    marginBottom: 6,
    marginTop: -8,
    width: "100%",
    textAlign: "left",
    fontWeight: 500,
  },
  optionsRow: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    fontSize: 15,
    marginBottom: 10,
  },
  rememberLabel: {
    display: "flex",
    alignItems: "center",
    gap: 8,
    cursor: "pointer",
    userSelect: "none",
  },
  toggle: {
    width: 32,
    height: 18,
    borderRadius: 10,
    position: "relative",
    marginRight: 3,
    display: "inline-block",
    verticalAlign: "middle",
    transition: "background 0.2s",
  },
  toggleKnob: {
    position: "absolute",
    top: 2,
    left: 2,
    width: 14,
    height: 14,
    background: "#fff",
    borderRadius: "50%",
    transition: "left 0.2s",
    boxShadow: "0 1px 4px rgba(0,0,0,0.12)",
  },
  forgotLink: {
    color: "#6a5af9", // purple theme color
    textDecoration: "none",
    fontWeight: 500,
    fontSize: 15,
    marginLeft: 8,
    cursor: "pointer",
    userSelect: "none",
    outline: "none",
  },
  button: {
    background: "#3f51f7",
    color: "#fff",
    border: "none",
    padding: "13px",
    borderRadius: 6,
    fontSize: 17,
    fontWeight: "bold",
    cursor: "pointer",
    marginBottom: 8,
    marginTop: 10,
    transition: "background 0.2s",
  },
  signupRow: {
    textAlign: "center",
    color: "#888",
    fontSize: 15,
    marginTop: 8,
  },
  signupLink: {
    color: "#6a5af9", // purple theme color
    textDecoration: "none",
    fontWeight: 500,
    marginLeft: 2,
    cursor: "pointer",
    userSelect: "none",
    outline: "none",
  },
};

export default Login;
